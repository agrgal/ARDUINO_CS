<?php

	include("connect.php"); 	
	
	$link=Connection();

	$result = mysqli_query($link, "SELECT * FROM tb_temperaturas ORDER BY tiempo DESC");
	
?>

<html>
   <head>
      <title>Sensor de temperatura</title>
      <META HTTP-EQUIV="refresh" CONTENT="5"> <!-- Se recarga cada 5 segundos -->
   </head>
<body>
   <h1>Lecturas de temperatura</h1>

   <table border="1" cellspacing="1" cellpadding="1">
		<tr>
			<td>&nbsp;Tiempo&nbsp;</td>
			<td>&nbsp;Temperatura 1&nbsp;</td>
		</tr>

      <?php 
		     while($row = mysqli_fetch_array($result)) {
		        printf("<tr><td> &nbsp;%s </td><td> &nbsp;%s&nbsp; </td></tr>", 
		           $row["tiempo"], $row["temperatura"]);
			   }
		     mysqli_free_result($result);
		     mysqli_close();
      ?>

   </table>
</body>
</html>
