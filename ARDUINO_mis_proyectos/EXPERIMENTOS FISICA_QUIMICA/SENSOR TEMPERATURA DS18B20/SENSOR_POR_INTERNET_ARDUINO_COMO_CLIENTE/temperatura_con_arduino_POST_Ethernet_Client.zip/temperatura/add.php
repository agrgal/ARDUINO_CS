<?php
   	include("connect.php");
   	
   	$link=Connection();

	$temp1=$_POST["temperatura"];
	$tiempo = $_POST["tiempo"];
	
	// $temp1="24";
	// $tiempo="2000";

	$query = "INSERT INTO tb_temperaturas (temperatura, tiempo) 
		VALUES ('".$temp1."','".$tiempo."')"; 
   	
   	mysqli_query($link, $query);
	mysqli_close($link);

   	header("Location: index.php");
?>
